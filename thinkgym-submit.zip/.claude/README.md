This folder shares my agent setup for Ralphthon.
Primary agent: Codex
Secondary agent: Claude Pro
